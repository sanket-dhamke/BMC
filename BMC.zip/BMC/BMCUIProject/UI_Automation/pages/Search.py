"""
This class contains all the test_amazon_search.py related method definition and object paths for webElements on Search page.
This class extends BaseClass to use all the generic methods for performing webElement actions.
"""
import pytest
from selenium.webdriver import Keys
from selenium.webdriver.common.by import By
from repository.objects import TestData
from pages.BasePage import BasePage
#from UI_Automation.repository.objects import TestData
#from UI_Automation.pages.BasePage import BasePage


@pytest.mark.usefixtures('init_driver')
class Search(BasePage):
    google_search = (By.XPATH, "//input[@title='Search']")
    amazon_text = (By.XPATH,"//span[normalize-space()='amazon']")
    amazon_in = (By.XPATH, "//h3[normalize-space()='Amazon.in']")
    amazon_search = (By.XPATH, "//input[@id='twotabsearchtextbox']")
    electronics = (By.XPATH, "//a[contains(text(),'Electronics')]")
    from_price = (By.XPATH,"// input[ @ id = 'low-price']")
    to_price = (By.XPATH, "// input[ @ id = 'high-price']")
    all_dell_result = (By.XPATH, "//span[@class='a-size-medium a-color-base a-text-normal']")
    search_result_dell = (By.XPATH, "//span[@class='a-color-state a-text-bold']")
    select_dell = (By.XPATH, "//div[@class='autocomplete-results-container']")
    go = (By.XPATH,"//input[@class='a-button-input']")


    # Constructor of class

    def __init__(self, driver):
        super().__init__(driver)
        try:
            self.driver.get(TestData.Base_url)
        except:
            print("Invalid URL")
            assert False

    # Page actions

    def do_amazon_search(self,search_txt):
        self.do_click(self.google_search)
        self.do_enter_value(self.google_search,"amazon")
        self.do_click(self.amazon_text)
        self.do_click(self.amazon_in)

        self.do_click(self.electronics)
        self.do_enter_value(self.amazon_search,search_txt)
        self.do_click(self.select_dell)

        self.do_enter_value(self.from_price,"20000")
        self.do_enter_value(self.to_price,"30000")
        self.do_click(self.go)
        #result = self.driver.find_elements_by_xpath(self.search_result_dell)
        print([my_elem.text+'\n' for my_elem in self.is_visible(self.all_dell_result)])


