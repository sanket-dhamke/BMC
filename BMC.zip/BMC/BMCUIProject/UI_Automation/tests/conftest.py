
"""
conftest.py contains common fixtures required for all the automation testcases for their execution.
Set the browser name in .UI_Automation/repository/repository.py and automation testcases will get executed in the respective browser.
No need to download drivers for browser . IT will be downloaded automatically as per the browser.
Tear down activity such as closing of browser will get executed post automation execution.
"""

import pytest
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.chrome.service import Service
from repository.objects import TestData


@pytest.fixture(params=[TestData.Browser],scope='class')
def init_driver(request):
    if request.param == 'chrome':
        web_driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
        web_driver.maximize_window()
    if request.param == 'firefox':
        web_driver = webdriver.Firefox(service=Service(GeckoDriverManager().install()))
    request.cls.driver = web_driver
    web_driver.implicitly_wait(5)
    yield
    web_driver.close()


