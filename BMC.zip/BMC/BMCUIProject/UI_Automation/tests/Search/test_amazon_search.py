"""
This will search "amazon" on google and then in the amazon website it will search "dell computers" in the search box of amazon.
After seraching the required text it will display all the results. Refer log .txt for more details.
Internally this will execute methods defined in /pages/Search.py through /pages/BasePage(contains common methods)
"""

import pytest

from repository.objects import TestData
from pages.Search import Search
from tests.test_BasePage import BaseTest


class TestLogin(BaseTest):

    def test_verify_dropdown_values(self):
        self.amazon_object = Search(self.driver)
        self.amazon_object.do_amazon_search(TestData.Text_To_Search)


