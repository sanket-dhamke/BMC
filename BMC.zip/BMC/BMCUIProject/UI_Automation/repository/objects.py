"""
Object Repository for Automation Framework.
Use keys directly inside test execution files.
"""


class TestData:
    Base_url = "https://google.com"  # NOTE: Pass the url of the webPage.
    Browser = "chrome"  # NOTE: Pass "chrome" or "firefox" as per your choice.
    Screenshot_dir = "D:/UI_Automation/screenshots/"  # NOTE: Pass absolute path of screenshot package
    Text_To_Search = "dell computers "


