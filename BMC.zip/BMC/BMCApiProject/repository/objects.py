"""
Object Repository for Automation Framework.
Use keys directly inside test execution files.
"""


class TestData:
    #Post call data for creating booking ID
    booking_url = "https://restful-booker.herokuapp.com/booking/"     # NOTE: Pass the url of the webPage.
    firstname = "Sanket"
    lastname = "Dhamke"
    totalprice = "220"
    depositpaid = "true"
    checkinDate = "2020-01-01"
    checkoutDate = "2020-01-04"
    additionalneeds = "breakfast"

    #Get Call data
    bookingID = "21524"    #Created booking ID for user Sanket

    #updated additional needs
    update_additionalNeeds = "breakfast"   # For update API change this value to "snacks" or "breakfast"

    user_name="admin"
    password="password123"

    #Delete data using booking ID. Open https://restful-booker.herokuapp.com/booking/ in browser and select any booking ID.
    deleteBookingID = "9004"  #25000 ,25900


