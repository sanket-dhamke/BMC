'''
Pass the booking ID and url which are mentioned in the /repository/objects.py file
'''
import requests
from repository.objects import *


def delete_user(create_url, bookingID):
    try:
        global response

        try:
            headers = {'content-type': 'application/json', 'Accept': 'application/json',
                       'Cookie': 'token=d1515b2a9428fec'}
            cookie = "token=d1515b2a9428fec"
            response = requests.delete(create_url + bookingID, auth=(TestData.user_name, TestData.password))
            assert response.status_code == 201


        except:
            print("Error: Please check the request parameters and refer the documentation for more details")

        # response.raise_for_status()
        return "Booking ID"+ bookingID +"has been deleted"

    finally:
        print("Test Execution completed")

