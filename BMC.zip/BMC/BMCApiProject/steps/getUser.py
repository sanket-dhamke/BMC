import pytest
import requests



def getUserInfo(url, bookingID):
    global response
    global body
    response = requests.get(url + bookingID)
    body = response.json()


def verifyUserName(name, lname):
    assert body['firstname'] == name
    assert body['lastname'] == lname


def verifyDepositPaid(deposit):
    assert (body['depositpaid']) == bool(deposit)


def verifyBookingDates(checkin, checkout):
    assert body['bookingdates']['checkin'] == checkin
    assert body['bookingdates']['checkout'] == checkout


def verifyTotalPrice(price):
    assert str(body['totalprice']) == price


def verifyAdditionalNeeds(need):
    assert body['additionalneeds'] == need


def verifyStatusCode():
    assert response.status_code == 200
