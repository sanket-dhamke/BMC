import requests
from repository.objects import *


def update_user(create_url, bookingID, firstname, lastname, totalprice, depositpaid, checkinDate, checkoutDate, additionalneeds):
    try:
        global response
        data = {
            "firstname": firstname,
            "lastname": lastname,
            "totalprice": totalprice,
            "depositpaid": depositpaid,
            "bookingdates": {
                "checkin": checkinDate,
                "checkout": checkoutDate
            },
            "additionalneeds": additionalneeds
        }

        try:
            headers = {'content-type': 'application/json', 'Accept': 'application/json', 'Cookie': 'token=d1515b2a9428fec'}
            cookie = "token=d1515b2a9428fec"
            response = requests.put(create_url+bookingID, json=data, auth=(TestData.user_name,TestData.password))

        except:
            print("Error: Please check the request parameters and refer the documentation for more details")
        
        #response.raise_for_status()
        body = response.json()
        assert response.status_code == 200
        return response.json()

    finally:
        print("Test Execution completed")

