import requests
from repository.objects import *


def create_user(create_url, firstname, lastname, totalprice, depositpaid, checkinDate, checkoutDate, additionalneeds):
    global response
    try:
        data = {
            "firstname": firstname,
            "lastname": lastname,
            "totalprice": totalprice,
            "depositpaid": depositpaid,
            "bookingdates": {
                "checkin": checkinDate,
                "checkout": checkoutDate
            },
            "additionalneeds": additionalneeds
        }

        try:
            response = requests.post(create_url, json=data)
        except:
            print("ISSUEEEEEEEEEEEEEEEEE")
        print(response)
        response.raise_for_status()
        body = response.json()
        assert response.status_code == 200
        assert body['booking']['firstname'] == firstname
        print(body['booking']['firstname'],"User is created")
        return body['bookingid']

    except:
        print("Error GOOOOO BACKKKK")
