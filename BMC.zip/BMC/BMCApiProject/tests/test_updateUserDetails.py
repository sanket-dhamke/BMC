'''
curl -X PUT \
  https://restful-booker.herokuapp.com/booking/1 \
  -H 'Content-Type: application/json' \
  -H 'Accept: application/json' \
  -H 'Cookie: token=abc123' \
  -d '{
    "firstname" : "James",
    "lastname" : "Brown",
    "totalprice" : 111,
    "depositpaid" : true,
    "bookingdates" : {
        "checkin" : "2018-01-01",
        "checkout" : "2019-01-01"
    },
    "additionalneeds" : "Breakfast"
}
'''
import pytest
import requests
from repository.objects import *
from steps.updateUser import *

'''
Pass all the required data which are mentioned in the /repository/objects.py file
Change update_additionalNeeds value as this is passed instead of additionalNeeds parameter mentioned in /repository/objects.py file
'''


def test_update_UserData():
    try:
        result = update_user(TestData.booking_url, TestData.bookingID, TestData.firstname, TestData.lastname,
                             TestData.totalprice,
                             TestData.depositpaid,
                             TestData.checkinDate, TestData.checkoutDate, TestData.update_additionalNeeds)
        print("User details has been updated,Please check", result)
    except:
        print("Error while updating the details")
