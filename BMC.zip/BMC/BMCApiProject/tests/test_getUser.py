'''
https://restful-booker.herokuapp.com/booking/1

op= HTTP/1.1 200 OK

{
    "firstname": "Sally",
    "lastname": "Brown",
    "totalprice": 111,
    "depositpaid": true,
    "bookingdates": {
        "checkin": "2013-02-23",
        "checkout": "2014-10-23"
    },
    "additionalneeds": "Breakfast"
}
'''
import pytest
import requests
from steps.getUser import *
from repository.objects import *

'''
Pass all the required data which are mentioned in the /repository/objects.py file
'''

def test_get_user_information():
    getUserInfo(TestData.booking_url, TestData.bookingID)

def test_verify_statusCode():
    verifyStatusCode()

def test_verify_name():
    verifyUserName(TestData.firstname, TestData.lastname)

def test_verify_depositPaid():
    verifyDepositPaid(TestData.depositpaid)

def test_verify_checkinDates():
    verifyBookingDates(TestData.checkinDate, TestData.checkoutDate)

def test_verify_totalPrice():
    verifyTotalPrice(TestData.totalprice)

def test_verify_additionalNeeds():
    verifyAdditionalNeeds(TestData.additionalneeds)
