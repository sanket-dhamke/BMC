'''
Pass the booking ID and url which are mentioned in the /repository/objects.py file
'''
import requests
import pytest
from steps.deleteUser import *


def test_delete_user():
    try:
        result = delete_user(TestData.booking_url,TestData.deleteBookingID)
        print(result)
    except:
        print("Error while deleting the user")
