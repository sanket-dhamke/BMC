'''
curl -X POST \
  https://restful-booker.herokuapp.com/booking \
  -H 'Content-Type: application/json' \
  -d '{
    "firstname" : "Jim",
    "lastname" : "Brown",
    "totalprice" : 111,
    "depositpaid" : true,
    "bookingdates" : {
        "checkin" : "2018-01-01",
        "checkout" : "2019-01-01"
    },
    "additionalneeds" : "Breakfast"
}'
'''
import pytest
import requests
from repository.objects import *
from steps.createUser import *

'''
Pass all the required data which are mentioned in the /repository/objects.py file
'''


def test_create_record():
    try:
        # Pass all the data required for creating new booking with booking ID
        result = create_user(TestData.booking_url, TestData.firstname, TestData.lastname, TestData.totalprice,
                             TestData.depositpaid,
                             TestData.checkinDate, TestData.checkoutDate, TestData.additionalneeds)
        print("User is created with booking id", result)
    except:
        print("User is not created")
