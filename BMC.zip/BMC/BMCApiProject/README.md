# **Automation Framework using pytest**

Using this automation framework user can automate create,get,update and delete bookings. You can refer https://restful-booker.herokuapp.com/apidoc/index.html#api-Booking-CreateBooking for more details.

**Pre-requisites: **

1. Download and install python 3.8 or latest. Refer https://www.python.org/downloads/
2. Optional: Download and Install Integrated development environment such as Pycharm . Refer https://www.jetbrains.com/pycharm/
3. Must have chrome or firefox browser on the system.

**How to use: **
1. Unzip the zip file.
2. Go to project root location and open the command prompt type and execute below commands
		> pip install requests
		> pip install pytest-html
		> pip install pytest
   1. Go to location /repository/objects.py under the project root path.
      1. Inside objects.py file user can provide value to key such as Url of application , Full name , browser name, organization name, Email and Verification message can even set the browser name where
         testcases will get executed.
      
       #Post call data for creating booking ID
       booking_url = "https://restful-booker.herokuapp.com/booking/"     # NOTE: Pass the url of the webPage.
       firstname = "Sanket"
       lastname = "Dhamke"
       totalprice = "220"
       depositpaid = "true"
       checkinDate = "2020-01-01"
       checkoutDate = "2020-01-04"
       additionalneeds = "breakfast"    

       #Get Call data
       bookingID = "21524"    #Created booking ID for user Sanket

       #updated additional needs
       update_additionalNeeds = "breakfast"   # For update API change this value to "snacks" or "breakfast"

       user_name="admin"
       password="password123"
    
       #Delete data using booking ID. Open https://restful-booker.herokuapp.com/booking/ in browser and select any booking ID.
       deleteBookingID = "9004"  #25000 ,25900
			
		
    Edit the values as per the requirement.
	
5. Now run the following command on project root path.
    If you are running this automation for first time then run test_createUserPost.py and take booking ID from /logs/log.txt
    you can replace the booking ID in /repository/objects.py file before running test_getUser.py file.
        
		
	In case user want to run only login testcase then execute below command 
        > pytest -s -v .\tests\test_getUser.py --html=./reports/report_getUser.html >> ./logs/log.txt
	    
	 
		
	Note: 
	 [1] Using '>>' operator we are copying console logs to log.txt file.
	 [2] '-s' is to capture the console output.
	 [3] '-x' will stop execution of automation on first failure. for example : url is invalid then it won't execute other testcases.
	 
6.  Post execution of the command verify html report which gets generated in /reports/report.html 

7. 	Try to change object values in /repository/objects.py and rerun the testcase.

** Framework Structure **

This framework is an implemenation of POM(Page Object Model) using pytest framework and selenium.

Folder structure:
				---API_Automation
								
								>--reports
                                        ->report_getUser.html
                                        ->report_deleteUser.html
								
								>--repository
                                        ->objects.py
								
								>--tests
								        ->test_createUserPost.py
										->test_getUser.py
                                        ..
                                        ..
								>--logs
                                        ->log.txt
								
								>--screenshots
								
								
	tests: All the executable testcases will be residing inside tests package .
	
	pages: All the method implementation for the testcases under tests package have been added into pages package.
	
	repository: This is the object repository for the automation framework which contains generic objects or elements and their actual values.
	
	reports: Post execution of the command mentioned in step 5 report will get generated in the reports package as a part of pytest-html plugin.
	
	logs: In this package log.txt will get generated and it will have the console logs.
	
	
						
						
						
					
					
	